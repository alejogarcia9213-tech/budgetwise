import { Label } from "@/components/ui/label";
import { NativeSelect } from "@/components/ui/native-select";
import { t } from "@/lib/i18n";
import { useAppStore, useProfile } from "@/lib/store";

export function MethodSelect({
  value,
  onChange,
  id,
}: {
  value?: string;
  onChange: (id: string) => void;
  id?: string;
}) {
  const lang = useAppStore((s) => s.lang);
  const methods = useProfile().paymentMethods.filter((m) => !m.archived);
  if (methods.length === 0) return null;
  return (
    <div>
      <Label htmlFor={id}>{t(lang, "budget.method")}</Label>
      <NativeSelect id={id} value={value ?? ""} onChange={(e) => onChange(e.target.value)} aria-label={t(lang, "budget.method")}>
        <option value="">{t(lang, "budget.methodNone")}</option>
        {methods.map((m) => (
          <option key={m.id} value={m.id}>
            {m.name}
          </option>
        ))}
      </NativeSelect>
    </div>
  );
}
