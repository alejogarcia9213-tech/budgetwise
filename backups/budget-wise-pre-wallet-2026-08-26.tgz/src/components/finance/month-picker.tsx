import { useEffect, useRef, useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight } from "lucide-react";
import { monthKeyFromParts, monthNames, monthTitle, nextMonthKey, prevMonthKey, yearOf } from "@/lib/dates";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function MonthPicker({ compact = false }: { compact?: boolean }) {
  const lang = useAppStore((s) => s.lang);
  const month = useAppStore((s) => s.activeMonth);
  const setMonth = useAppStore((s) => s.setMonth);
  const [open, setOpen] = useState(false);
  const [year, setYear] = useState(() => Number(yearOf(month)));
  const rootRef = useRef<HTMLDivElement>(null);
  const names = monthNames(lang);
  const selectedMonth = Number(month.slice(5));

  useEffect(() => {
    setYear(Number(yearOf(month)));
  }, [month]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  return (
    <div ref={rootRef} className="relative min-w-0 flex-1">
      <div className="flex items-center gap-2">
        {compact ? null : (
          <button
            type="button"
            className="flex size-11 shrink-0 items-center justify-center rounded-md bg-elevated text-fg hover:bg-card"
            aria-label={t(lang, "cal.prev")}
            onClick={() => setMonth(prevMonthKey(month))}
          >
            <ChevronLeft className="size-5" />
          </button>
        )}
        <button
          type="button"
          className="flex h-11 min-w-0 flex-1 items-center justify-center gap-2 rounded-md bg-elevated px-3 text-sm font-medium card-shadow"
          aria-haspopup="dialog"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <CalendarDays className="size-4 shrink-0 text-muted" />
          <span className="truncate">{monthTitle(month, lang)}</span>
        </button>
        {compact ? null : (
          <button
            type="button"
            className="flex size-11 shrink-0 items-center justify-center rounded-md bg-elevated text-fg hover:bg-card"
            aria-label={t(lang, "cal.next")}
            onClick={() => setMonth(nextMonthKey(month))}
          >
            <ChevronRight className="size-5" />
          </button>
        )}
      </div>
      {open ? (
        <div
          role="dialog"
          aria-label={t(lang, "budget.pickPeriod")}
          className="absolute top-[calc(100%+0.5rem)] left-0 z-40 w-full rounded-xl bg-card p-3 card-shadow"
        >
          <div className="mb-3 flex items-center justify-between">
            <button
              type="button"
              className="flex size-10 items-center justify-center rounded-md hover:bg-elevated"
              aria-label={t(lang, "budget.prevYear")}
              onClick={() => setYear((y) => y - 1)}
            >
              <ChevronLeft className="size-4" />
            </button>
            <p className="text-sm font-semibold tabular">{year}</p>
            <button
              type="button"
              className="flex size-10 items-center justify-center rounded-md hover:bg-elevated"
              aria-label={t(lang, "budget.nextYear")}
              onClick={() => setYear((y) => y + 1)}
            >
              <ChevronRight className="size-4" />
            </button>
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {names.map((label, i) => {
              const m = i + 1;
              const key = monthKeyFromParts(year, m);
              const selected = year === Number(yearOf(month)) && m === selectedMonth;
              return (
                <button
                  key={key}
                  type="button"
                  className={cn(
                    "h-11 rounded-md text-sm font-medium",
                    selected ? "bg-primary text-primary-fg" : "bg-elevated text-fg hover:bg-card",
                  )}
                  onClick={() => {
                    setMonth(key);
                    setOpen(false);
                  }}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>
      ) : null}
    </div>
  );
}
