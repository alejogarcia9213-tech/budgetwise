export interface TipSnapshot {
  netIncome: number;
  essentialExpenses: number;
  flexibleExpenses: number;
  savings: number;
  investments: number;
  debts: number;
  netWorth: number;
  liquidityMonths: number;
  savingsInvestmentRate: number;
  leftToBudget: number;
  leftover: number;
}

export interface Tip {
  id: string;
  en: string;
  es: string;
}

const TIPS: { id: string; when: (s: TipSnapshot) => boolean; en: string; es: string }[] = [
  {
    id: "emergency",
    when: (s) => s.liquidityMonths < 3,
    en: "Your cash buffer covers less than three months of essentials. Park the next leftover euro in an emergency fund before adding new lifestyle spend.",
    es: "Tu colchón cubre menos de tres meses de gastos esenciales. Destina el siguiente euro libre al fondo de emergencia antes de aumentar el ocio.",
  },
  {
    id: "over-allocate",
    when: (s) => s.leftToBudget < -1,
    en: "Planned allocations exceed this month's income. Lower a target percentage or trim an adjustment so every euro has a job without going over.",
    es: "Las asignaciones previstas superan los ingresos del mes. Baja un porcentaje o un ajuste para que cada euro tenga un propósito sin pasarte.",
  },
  {
    id: "unallocated",
    when: (s) => s.leftToBudget > 20,
    en: "You still have money left to budget. Give it a job — debt extra, emergency fund, or the investment line — so it does not leak into impulse spend.",
    es: "Todavía te queda dinero por asignar. Dale un propósito: extra a deuda, fondo de emergencia o inversión, para que no se escape en impulsos.",
  },
  {
    id: "flex-high",
    when: (s) => s.netIncome > 0 && s.flexibleExpenses / s.netIncome > 0.3,
    en: "Flexible spending is eating more than 30% of income. Pick one recurring treat to pause this month and move that amount to savings.",
    es: "El gasto flexible supera el 30% de tus ingresos. Elige un capricho recurrente para pausar este mes y mueve ese importe al ahorro.",
  },
  {
    id: "save-rate",
    when: (s) => s.savingsInvestmentRate < 20 && s.netIncome > 0,
    en: "Your savings-investment rate is under 20%. Automate a transfer the day income lands so the rate does not depend on leftover willpower.",
    es: "Tu tasa de ahorro-inversión está por debajo del 20%. Automatiza una transferencia el día que cobra para no depender de la voluntad.",
  },
  {
    id: "debt-first",
    when: (s) => s.debts > 0 && s.investments > 0 && s.savingsInvestmentRate > 0,
    en: "You are investing while carrying debt. Keep a small automated invest, then throw extra cash at the highest APR — interest saved is a guaranteed return.",
    es: "Estás invirtiendo con deudas. Mantén una inversión automática pequeña y lanza el extra a la APR más alta: el interés evitado es una rentabilidad segura.",
  },
  {
    id: "debt-heavy",
    when: (s) => s.debts > 0 && s.netWorth < s.debts,
    en: "Liabilities outweigh assets. Freeze new borrowing and run avalanche or snowball until the snowball of freed minimums is working for you.",
    es: "Los pasivos superan a los activos. Congela nuevo crédito y usa avalancha o bola de nieve hasta que los mínimos liberados trabajen a tu favor.",
  },
  {
    id: "invest-habit",
    when: (s) => s.investments === 0 && s.netIncome > 0 && s.leftover > 0,
    en: "Nothing is invested this month. Even a small ETF contribution turns leftover cash into a working asset instead of a larger checking balance.",
    es: "Este mes no hay inversión. Aunque sea una aportación pequeña a un ETF, convierte el sobrante en un activo que trabaja.",
  },
  {
    id: "positive-nw",
    when: (s) => s.netWorth > 0 && s.savingsInvestmentRate >= 20 && s.liquidityMonths >= 3,
    en: "Liquidity, savings rate and net worth are all in a healthy range. Raise the investment contribution by 1% of income and leave it on autopilot.",
    es: "Liquidez, tasa de ahorro y patrimonio están en rango saludable. Sube la aportación a inversión un 1% de ingresos y déjala en piloto automático.",
  },
  {
    id: "essentials-tight",
    when: (s) => s.netIncome > 0 && s.essentialExpenses / s.netIncome > 0.7,
    en: "Essentials are taking more than 70% of income. Review rent, utilities and groceries for one recurring cut — that is the fastest way to free a savings line.",
    es: "Lo esencial se lleva más del 70% de los ingresos. Revisa alquiler, suministros y comida para un recorte recurrente: es la vía más rápida para liberar ahorro.",
  },
  {
    id: "leftover-cash",
    when: (s) => s.leftover > 50 && s.savings === 0,
    en: "The month still shows a cash surplus with no savings contribution. Sweep that leftover into your emergency fund before the next payday.",
    es: "El mes cierra con superávit y sin aportación a ahorro. Pasa ese resto al fondo de emergencia antes de la siguiente nómina.",
  },
  {
    id: "on-track",
    when: () => true,
    en: "Keep recording every spend the day it happens. The budget is only as honest as the ledger — two minutes now prevents a surprise at month-end.",
    es: "Sigue anotando cada gasto el día que ocurre. El presupuesto solo es honesto si el libro lo es: dos minutos ahora evitan sorpresas a fin de mes.",
  },
];

export function generateFinancialTips(snapshot: TipSnapshot, excludeId?: string): Tip[] {
  return TIPS.filter((tip) => tip.id !== excludeId && tip.when(snapshot)).map(({ id, en, es }) => ({
    id,
    en,
    es,
  }));
}

export function pickTip(snapshot: TipSnapshot, excludeId?: string): Tip {
  const applicable = generateFinancialTips(snapshot, excludeId);
  const pool = applicable.length > 0 ? applicable : generateFinancialTips(snapshot);
  return pool[Math.floor(Math.random() * pool.length)] ?? {
    id: "on-track",
    en: TIPS[TIPS.length - 1].en,
    es: TIPS[TIPS.length - 1].es,
  };
}
