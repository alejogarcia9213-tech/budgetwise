type WorkerLike = {
  recognize: (image: Blob) => Promise<{ data: { text: string } }>;
  setParameters: (p: Record<string, string>) => Promise<unknown>;
  terminate: () => Promise<void>;
};

let workerPromise: Promise<WorkerLike> | null = null;
let progressCb: ((pct: number) => void) | undefined;

async function getWorker(onProgress?: (pct: number) => void): Promise<WorkerLike> {
  progressCb = onProgress;
  if (!workerPromise) {
    workerPromise = (async () => {
      const { createWorker } = await import("tesseract.js");
      const worker = await createWorker("eng+spa+deu+fra+por+ita", 1, {
        logger: (m: { status?: string; progress?: number }) => {
          if (m.status === "recognizing text" && typeof m.progress === "number") {
            progressCb?.(Math.round(m.progress * 100));
          }
        },
      });
      await worker.setParameters({
        tessedit_pageseg_mode: "6",
      } as never);
      return worker as unknown as WorkerLike;
    })().catch((err) => {
      workerPromise = null;
      throw err;
    });
  }
  return workerPromise;
}

async function preprocess(file: Blob): Promise<Blob> {
  if (typeof createImageBitmap !== "function" || typeof document === "undefined") return file;
  try {
    const img = await createImageBitmap(file);
    const max = 1800;
    const scale = Math.min(max / Math.max(img.width, img.height), 2.2);
    const w = Math.max(1, Math.round(img.width * scale));
    const h = Math.max(1, Math.round(img.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    const data = ctx.getImageData(0, 0, w, h);
    const d = data.data;
    for (let i = 0; i < d.length; i += 4) {
      let y = 0.299 * d[i]! + 0.587 * d[i + 1]! + 0.114 * d[i + 2]!;
      y = (y - 128) * 1.7 + 128;
      y = y < 30 ? 0 : y > 210 ? 255 : y;
      d[i] = d[i + 1] = d[i + 2] = y;
    }
    ctx.putImageData(data, 0, 0);
    img.close();
    const blob: Blob | null = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
    return blob ?? file;
  } catch {
    return file;
  }
}

/** Reads text from a receipt photo. Failures return "" so the rest of the app stays up. */
export async function ocrImage(file: Blob, onProgress?: (pct: number) => void): Promise<string> {
  try {
    const prepared = await preprocess(file);
    const worker = await getWorker(onProgress);
    const { data } = await worker.recognize(prepared);
    return String(data.text ?? "").trim();
  } catch {
    return "";
  }
}
